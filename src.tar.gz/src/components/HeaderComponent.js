import React from 'react';
// import React, {Component} from 'react';
import {View, Text, Button} from 'react-native';

type PropsType = {
  toggleProfileiState: () => void,
  toggleUiState: () => void
};

export default class HeaderComponent extends React.Component < void,
PropsType,
void > {
     componentDidMount() {
          console.log("in componentDidMount of header",this.props);
     }
     componentDidUpdate(prevProps, prevState){
          console.log("in componentDidUpdate",this.props.profileState);
     }
     changeProfileState(){
          console.log("in changeProfileState");
          this.props.toggleProfileiState();
     }
     changeUiState(){
          console.log("in changeUiState");
          this.props.toggleUiState();
     }

     render() {
          console.log("in render of HeaderComponent");
          return (
               <View>
                    <Text>
                    In header {this.props.profileState} yipee
                    </Text>
                    <Button onPress={() => {this.changeProfileState()}} title="Chang1e Profile State"/>
                    <Button onPress={() => {this.changeUiState()}} title="Change UI State"/>

               </View>
          );
     }
}
