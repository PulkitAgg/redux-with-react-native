// @flow

export const APIServer: string = 'http://board.lzr.io';
