// @flow

import { TOGGLE_PROFILE_STATE } from './constants';

// export const toggleProfileiState = () => ({ type: TOGGLE_PROFILE_STATE });



export const toggleProfileiState = () => (dispatch: any) => {
     console.log(" in toggleProfileiState in actions");
            dispatch({
                 type : TOGGLE_PROFILE_STATE,
            });
         };
