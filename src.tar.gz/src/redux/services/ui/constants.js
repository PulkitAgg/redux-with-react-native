// @flow

export const TOGGLE_UI_STATE = 'TOGGLE_UI_STATE';
