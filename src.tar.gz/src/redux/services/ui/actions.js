// @flow

import { TOGGLE_UI_STATE } from './constants';

export const toggleUiState = () => ({ type: TOGGLE_UI_STATE });
